"""
NU biped - Robot Controller Program
Written by Zhenis Otarbay
Code refactoring by Tibor Santa, Sebastian
"""
import socket
from tkinter import *
from tkinter.ttk import Notebook, Style
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from math import pi, sin, cos, radians
import math
from numpy import matrix, double, vectorize
import random
import os
#import msvcrt
import sys
##import termios
##import tty 
#from dynamixel_sdk import *
def isnumeric2(x): 
    return x.replace("-", "").replace(".", "").isnumeric()

class RobotController(Frame):

    def __init__(self, master):
        """Set up the Graphic User Interface"""
        super().__init__(master)
        #master is the app self (master = tkinter.Tk()).
        self.master = master
        #master.title makes a title on the title bar of the app.
        self.master.title("NU-biped Teach Pendant")
        #master.protocol makes the app quit after user pressed exit button.
        self.master.protocol('WM_DELETE_WINDOW', self.close_app)
        #self.master.config("Verdana", 14)
        #self.master.add_command(label="Something", font=("Verdana", 14))
        # Define Style
        MYGREEN = '#d2ffd2'
        MYRED = '#dd0202'
        self.style = Style()
        self.style.theme_create('mfx', parent='alt', settings={
            'TNotebook': {'configure': {'tabmargins': [2, 5, 2, 0]}},
            'TNotebook.Tab': {
                'configure': {'padding': [5, 1], 'background': MYGREEN, 'font': ('Helvetica', 16)},
                'map': {'background': [('selected', MYRED)],
                        'expand': [('selected', [1, 1, 1, 0])]}}})
        self.style.theme_use('mfx')

        # Define Notebook tabs
        #Notebook creation.
        self.pages = Notebook(self)
        self.pages.pack(side=LEFT)  # this is the notebook (with the colored tabs)

        #Creation of pages.
        global page
        self.page = []  # list holds the 4 notebook pages
        for key, val in enumerate(['Connect', 'Left Leg', 'Right Leg', 'Inverse Kinematics']):
            self.page.append(Frame())
            self.page[key].pack()
            #self.pages.config("Verdana", 32)
            self.pages.add(self.page[key], text=val)
            #self.pages.add_command(label="Something", font=("Verdana", 14))
        #A list for the figures, to indicate whether there are any figures active,
        #The information of active_graphs will be needed soon for closing the active figures, when new are opened.
        global active_graphs
        active_graphs = []
        
        # Define the Canvas for the Graph. we should 
        self.graph = plt.figure()
        active_graphs.append(self.graph)
        #Creates a place for plots to be displayed on.
        self.canvas = FigureCanvasTkAgg(self.graph, master=self)  # A tk.DrawingArea.
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(side=RIGHT, fill=BOTH, expand=True)
        
        self.ax = self.graph.add_subplot(111, projection='3d')
        self.ax.set_xlim([-9, 9])
        self.ax.set_ylim([-9, 9])
        self.ax.set_zlim([-9, 9])
        #ax.quiver(0, 0, 0, 4, 0, 0, color='red')
        #ax.text(4, 0, 0, '{X_0}', fontsize=8, color='red')
        #self.add_arrow(0, 0, 0, 0, 0, 0) 

        # Define Buttons on Connect Tab
        #self.image_plan = PhotoImage(file='plan.png')
        self.image_con = PhotoImage(file='green_con_button.gif')
        self.image_dis = PhotoImage(file='discon_but.png')
        self.plan = Canvas(self.page[0], width=298, height=449)
       # self.plan.create_image(0, 0, image=self.image_plan, anchor=NW)
        self.plan.pack(side=TOP)
        self.button = {}  # buttons are kept in a dictionary
        self.button['con'] = Button(self.page[0], text='Connect', bg='white', image=self.image_con, command=self.conn)
        self.button['dis'] = Button(self.page[0], text='Disconnect', bg='white', image=self.image_dis, command=self.disconn)
        #self.button['con'].place(rely=0.2,relx=0.5)
        #self.button['dis'].place(rely=0.5,relx=0.5)
        self.button['con'].pack(side=LEFT, pady=20, padx=20)
        self.button['dis'].pack(side=RIGHT, pady=20, padx=20)
        # Define Left Leg Tab

        global connection_variables
        connection_variables = {
            "host":'169.254.16.136',
            "port":12345,
            ("gap", 1): None,
            "PROTOCOL_VERSION": 1.0,
            "BAUDRATE": 57600,
            "DEVICENAME": "/dev/ttyUSB0",
            "ADDR_MX_TORQUE_ENABLE": 64,
            "ADDR_MX_GOAL_POSITION": 116,
            "ADDR_MX_PRESENT_POSITION": 132,
            "DXL_ID": 1,
            "DXL_MINIMUM_POSITION_VALUE": 10,
            "DXL_MAXIMUM_POSITION_VALUE": 4000,
            "DXL_MOVING_STATUS_THRESHOLD": 20,
            "TORQUE_ENABLE": 1,
            "TORQUE_DISABLE": 0
        }
        global labels2
        labels2 = []
        global entries2
        entries2 = []
        for i, j in enumerate(connection_variables):
            if j[0] != "gap":
                labels2.append(Label(self.page[0], text=j))
                entries2.append(Entry(self.page[0]))
                labels2[i].pack()
                entries2[i].pack()
                labels2[i].place(relx=0, rely=i*0.04)
                entries2[i].place(relx=0.7, rely=i*0.04)
                entries2[i].insert(0, connection_variables[j])
            else:
                labels2.append(None)
                entries2.append(None)

        def update_connection_variables():
            for i, j in enumerate(connection_variables):
                if entries2[i] != None:
                    connection_variables[j] = entries2[i].get()
                print("updated", j, "to", connection_variables[j])

        button_of_tomatoe_update = Button(self.page[0], text="update", command=update_connection_variables)
        button_of_tomatoe_update.config(width=20, height=2)
        button_of_tomatoe_update.pack()
        button_of_tomatoe_update.place(relx=0.35, rely=0.6)
        
        def update_slider(event, edit, slider):
            if len(edit.get()):
                for c in edit.get():
                    if not isnumeric2(c):
                        slider.set(0)
                        edit.delete(0, "end")
                        edit.insert(0, "0")
                        return
                slider.set(float(edit.get()))
            else:
                slider.set(0)

        self.l_scale, self.l_label, self.l_entry = [], [], []
        self.r_scale, self.r_label, self.r_entry = [], [], []

        #scale is the slider
        #label is the text next to the textbox
        #entry is the textbox.

        #both is a list of left and right, for 2 almost identical pages to be able to be looped and thus shorted.
        global both_scale, both_label, both_entry
        both_scale, both_label, both_entry = [self.l_scale, self.r_scale], [self.l_label, self.r_label], [self.l_entry, self.r_entry]

        global labels
        labels = ['hip y', 'hip r', 'hip p', 'knee p', 'ankle y', 'ankle r']
        
        self.left = [IntVar(self.master, _) for _ in range(6)]
        self.right = [IntVar(self.master, _) for _ in range(6)]
        N=10
        global both
        both = [self.left, self.right]
        #quit in page 2, 3
        q=Button(self.page[1], text="quit")
        q.bind('<Button-1>',quit)
        q.grid(row=N+3,column=0)
        #Exit button
        q=Button(self.page[2], text="quit")
        q.bind('<Button-1>',quit)
        q.grid(row=N+3,column=0)
        #Send button in page 2,3
        def send1():

            str=""

            for i in range(0,len(entries)):

                str=str+entries[i].get()+"_"

                print(i)

            #s.send(str)

            #forward_left_leg(double(sliders[0].get()),double(sliders[1].get()),double(sliders[2].get()),double(sliders[3].get()),double(sliders[4].get()),double(sliders[5].get()))

            #plt.close()

        

        def send2():

            str=""

            for i in range(0,len(entries)):

                str=str+entries[i].get()+"_"

        #s.send(str)
        send=Button(self.page[1], text="send")##, command=ForwardKinematics.send1)

        send.grid(row=N+2,column=0)

        #Connect button

        #conn=Button(subframe2, text="Connect", command=conn)

        #conn.grid(row=0,column=0)

        send2=Button(self.page[2], text="send")##, command=ForwardKinematics.send2)

        send2.grid(row=N+2,column=0)

        for i in range(len(both)):
            #0 = left
            #1 = right
            sublabel = []
            for j in range(len(both[i])):
                self.update_graph(*list(map(IntVar.get, both[i])), indicater=i)
                both_scale[i].append(Scale(self.page[i+1], variable=both[i][j], from_=-90, to=90, orient=HORIZONTAL, tickinterval=15, length=440, width=40))
                both_scale[i][j].bind('<ButtonRelease-1>', lambda e, i=i, j=j: both[i][j].get())
                both_scale[i][j].grid(row=j, column=0)
                
                #Next loop will give names to the textboxes.
                
                sublabel.append(Label(self.page[i+1], text=labels[j]))
                sublabel[j].place(relx=0.890, rely=0.015 + 0.145*j)
      
                
                both_entry[i].append(Entry(self.page[i+1], text=labels[j], width=8))
                both_entry[i][j].grid(row=j, column=2)
                
                both_entry[i][j].bind('<KeyRelease>', lambda y=i,arg1=both_scale[i][j],arg2=both_entry[i][j]:update_slider(y,arg2,arg1))

        texts = [None, "y (Leg 1)"]+[None]*4
        global e
        e = []
        l = []
        for i in texts:
            if i != None:
                e.append(Entry(self.page[3], text=i))
            else:
                e.append(Entry(self.page[3]))

        texts = []
        leftnright = ["left", "right"]
        for i in range(2):
            for j in range(3):
                texts.append(chr(120+j)+" (Leg "+leftnright[i]+")")
        
        for i in range(6):
            l.append(Label(self.page[3], text=texts[i]))
            l[i].pack()
            l[i].place(relx=0, rely=(i+1)*0.050)
            e[i].pack()
            e[i].config(width=7)
            e[i].insert(0, "0")
            e[i].place(relx=0.20, rely=(i+1)*0.050)
        texts_left_leg_results=["t1", "t2","t3","t4","t5","t6"]

    
        for i in range(6):
            l.append(Label(self.page[3],text=texts_left_leg_results[i]))
            l[i+6].pack()
            l[i+6].place(rely=(i+1)*0.050,relx=0.40)
            e.append(Entry(self.page[3]))
            e[i+6].pack()
            e[i+6].config(width=7)
            e[i+6].insert(0,"")
            e[i+6].place(rely=(i+1)*0.050,relx=0.50)

        for i in range(6):
            e.append(Entry(self.page[3]))
            e[i+12].pack()
            e[i+12].config(width=7)
            e[i+12].insert(0, "")
            e[i+12].place(rely=(i+1)*0.050, relx=0.70)
            
        l.append(Label(self.page[3],text="LL IK r"))
        l[12].pack()
        l[12].place(rely=0,relx=0.50)
        l.append(Label(self.page[3], text="RL IK r"))
        l[13].pack()
        l[13].place(rely=0,relx=0.70)
        
        global randomnumbers
        randomnumbers = [[0.0]*3]*2

        global alp, bet, gam
        alp, bet, gam = (0,)*3
        def inverse_kin_leg(ikli): 
            assert ikli in (0, 1), "Varible ikli in method inverse_kin_leg must be either 0 or 1"
            p = {"squaresum":0}

            for i in range(6):
                if not isnumeric2(e[i].get()):
                    e[i].delete(0, END)
                    e[i].insert(0, 0)
            
            for i, j in enumerate(("x", "y", "z")):
                p[j] = float(e[ikli*3+i].get())
                p["squaresum"] += float(p[j])**2
            L3 = 318.5
            L4 = 318.5
            c4 = (p["squaresum"] - L3**2 - L4**2)**2
            t = [None, None, None, math.atan2(math.sqrt(math.fabs(1 - c4**2)), c4), None, None]
            k = [L3*math.cos(t[3]) + L4, L3*math.sin(t[3]), math.sqrt(p["squaresum"])]
            t[4] = math.atan2((k[1]*k[2]-p["z"])/(k[0]+k[1]**2/k[0]),(k[2]+k[1])/k[0]*(k[1]*k[2]/k[0]-p["z"]/(k[0]+k[1]**2/k[0])))
            t.append(t[3]+t[4]) #Too many "t[3] + t[4]" have been used, so allowed all to be replaced with "t[6]".
            t[5] = math.atan2(p["y"], -p["x"])
            s2 = -math.sin(alp)*math.sin(t[5])*math.sin(t[6])*math.cos(bet) + math.sin(bet)*math.sin(t[3] + t[4])*math.cos(t[5]) + math.cos(alp)*math.cos(bet)*math.cos(t[6])
            c2 = math.sqrt(1-s2**2)
            t[1] = math.atan2(s2, c2)
            t2_rad = math.radians(t[1])
            t[0] = math.atan2((-(math.sin(alp)*math.cos(gam) - math.sin(bet)*math.sin(gam)*math.cos(alp))*math.cos(t[6]) + (math.sin(alp)*math.sin(bet)*math.sin(gam) + math.cos(alp)
  *math.cos(gam))*math.sin(t[5])*math.sin(t[6]) - math.sin(gam)*math.sin(t[6])*math.cos(bet)*math.cos(t[5]))/c2,((math.sin(alp)*math.sin(gam) + math.sin(bet)*math.cos(alp)*math.cos(gam))*math.cos(t[6]) + (math.sin(alp)*math.sin(bet)*math.cos(gam) - math.sin(gam)*
  math.cos(alp))*math.sin(t[5])*math.sin(t[6]) - math.sin(t[6])*math.cos(bet)*math.cos(gam)*math.cos(t[5]))/c2)
            t[2] = math.atan2((math.sin(alp)*math.cos(bet)*math.cos(t[5]) - math.sin(bet)*math.sin(t[5]))/c2,-( -math.sin(alp)*math.sin(t[5])*math.cos(bet)*math.cos(t[6]) - math.sin(bet)*math.cos(t[5])*math.cos(t[6]) + math.sin(t[6])*math.cos(alp)*math.cos(bet
  ))/c2)
            #e[3].insert(0, t[4]) if ikli else e[4].insert(0, radians(t[1]))
            for i in range(6):
                print("given:", e[i].get())
            for i in range(6):
                e[(ikli+1)*6+i].delete(1, END)
                e[(ikli+1)*6+i].insert(0, repr(t[i]))
        
        for i in range(2):
            self.button['draw'+repr(i)] = Button(self.page[i+1], text='Update Graph', bg='white', command=lambda i=i: self.update_graph(*list(map(IntVar.get, both[i])), indicater=i))
            self.button['draw'+repr(i)].grid(row=7, column=0, columnspan=2)

        print(list(map(IntVar.get, self.left)))

        b = []
        b.append(Button(self.page[3], text="Left Leg IK", command=lambda: inverse_kin_leg(0)))
        b[0].config(width=10)
        b[0].pack()
        b[0].place(relx=0.3, rely=0.9)
        b.append(Button(self.page[3], text="Right Leg IK", command=lambda: inverse_kin_leg(1)))
        b[1].config(width=10)
        b[1].pack()
        b[1].place(relx=0.5, rely=0.9)

    def update_graph(self, *theta, **side):
        print(side)
        """Add a quiver arrow to the plot"""
        self.ax.clear()
        self.ax.set_xlim([-9, 9])
        self.ax.set_ylim([-9, 9])
        self.ax.set_zlim([-9, 9])
        
        alf = [0, (-pi) / 2, pi / 2, -pi / 2, 0, pi / 2]
        a = [0, 0, 0, 318, 318, 0]
        d = [0, 0, 0, 0, 0, 0]
        t = []
        for i in range(len(theta)):
            t.append(radians(theta[i]))
        t[1] += pi / 2
        T_keys = ["01", "12", "23", "34", "45", "56"]
        T_length = len(T_keys)
        T = {}
        for i in range(T_length):
            j = T_keys[i]
            T[j] = matrix([
                [cos(t[i]), -sin(t[i]), 0, a[i]],
                [sin(t[i]) * cos(alf[i]), cos(t[i]) * cos(alf[i]), -sin(alf[i]), -sin(alf[i]) * d[i]],
                [sin(t[i]) * sin(alf[i]), cos(t[i]) * sin(alf[i]), cos(alf[i]), cos(alf[i]) * d[i]],
                [0, 0, 0, 1]
            ])
        L5 = 50 
        L6 = 100
        T["6F"] = matrix([
            [0, 0, -1, L5],
            [0, 1, 0, 0],
            [1, 0, 0, L6],
            [0, 0, 0, 1]
        ])
        
        for i in range(2, 7):
            T["0" + repr(i)] = T["0" + repr(i - 1)] * T[repr(i - 1) + repr(i)]
        
        T["0F"] = T["06"] * T["6F"]
        #fig = plt.figure()
        #ax = fig.add_subplot(111, projection="3d")
        #ax.set_xlim([-9, 9])
        #ax.set_ylim([-9, 9])
        #ax.set_zlim([-10, 9])

        scales = [4, 3.5, 2, 1]
        scaleD = 80
        orange = [0.9100, 0.4100, 0.1700]
        Fontscale = 11

        colors = ["red", "blue", "green", "orange", "orange", "orange", "green", "red"]
        sbxyz = ["X", "Y", "Z"]
        for i in range(3):
            argli = [0, 0, 0, 0, 0]
            argli.insert(i + 3, scales[0])  #argli: argument list, used to allow function arguments change places by the loop.
            ##print(argli)
            self.ax.quiver(argli[0], argli[1], argli[2], argli[3], argli[4], argli[5], color=colors[0])
            #T01*T12*T23=T03
            #T34
            argli = [0, 0]
            argli.insert(i, scales[0])
            sbtext = "{" + sbxyz[i] + "_0}"
            self.ax.text(argli[2], argli[1], argli[2], sbtext, fontsize=8, color=colors[0])
        # squarebracket zyx
        for i in range(1, 4):
            for j in range(3):
                argli = []
                for k in range(3):
                    argli.append(T["0" + repr(i)][k, j] * scales[i])
                self.ax.quiver(0, 0, 0, argli[0], argli[1], argli[2], color=colors[i])
                argli = []
                for k in range(3):
                    argli.append(double(T["0" + repr(i)][k, j]) * scales[i])

                sbtext = "{" + sbxyz[j] + "_" + repr(i) + "}"
                self.ax.text(argli[0], argli[1], argli[2], sbtext, fontsize=8, color=colors[i])
        squidfunc = lambda x: (3 + x // 3, 2 + x % 2, 3 + x // 3)  # sqale quick function
        for i in range(4, 7):
            squidresult = squidfunc(i - 4)
            for j in range(3):
                argli = []
                for k in range(3):
                    argli.append(double(T["0" + repr(i)][k, 3]) / scaleD)
                for k in range(3):
                    argli.append(double(T["0" + repr(i)][k, j]) * scales[squidresult[k]])
                self.ax.quiver(argli[0], argli[1], argli[2], argli[3], argli[4], argli[5], color=colors[i])
            for j in range(3):
                argli = []
                for k in range(3):
                    argli.append((double(T["0" + repr(i)][k, 3])) / scaleD + double(T["0" + repr(i)][k, j]) * scales[
                        squidresult[k]])
                sbtext = "{" + sbxyz[j] + "_" + repr(i) + "}"
                self.ax.text(argli[0], argli[1], argli[2], sbtext, fontsize=8, color=colors[i])


        self.ax.plot([0, double(T["04"][0,3])/scaleD],
             [0, double(T["04"][1,3])/scaleD],
             [0, double(T["04"][2,3])/scaleD],
             "--k")
        self.ax.plot([double(T["04"][0,3])/scaleD, double(T["05"][0,3])/scaleD],
             [double(T["04"][1,3])/scaleD, double(T["05"][1,3])/scaleD],
             [double(T["04"][2,3])/scaleD, double(T["05"][2,3])/scaleD],
             "--k")
        self.ax.plot([double(T["06"][0,3])/scaleD, double(T["0F"][0,3])/scaleD],
              [double(T["06"][1,3])/scaleD, double(T["0F"][1,3])/scaleD],
              [double(T["06"][2,3])/scaleD, double(T["0F"][2,3])/scaleD],
              "--k")
        scaleF_text = 20000
        for i in range(3):
            argli = []
            for j in range(3):
                argli.append(double(T["0F"][j, 3]) / scaleD)
            for j in range(3):
                argli.append(double(T["0F"][j, i]) * scales[2])
            self.ax.quiver(argli[0], argli[1], argli[2], argli[3], argli[4], argli[5], color=colors[7])
        for i in range(3):
            argli = []
            for j in range(3):
                argli.append(double(T["0F"][j, 3]) / scaleD + double(T["0F"][j, i]) * scales[2])
            sbtext = "{" + sbxyz[i] + "_F}"
            self.ax.text(argli[0], argli[1], argli[2], sbtext, fontsize=8, color=colors[7])
        convert_to_int = vectorize(lambda x: int(x))
        for i in T:
            ##print(i)
            T[i] = convert_to_int(T[i])
            ##print(T[i])
        self.canvas.draw()

    global s
    s = socket.socket()
    def conn(self):
        if os.name == 'nt':
            def getch():
                return msvcrt.getch().decode()
        else:
            fd = sys.stdin.fileno()
            old_settings = termios.tcgetattr(fd)
            def getch():
                try:
                    tty.setraw(sys.stdin.fileno())
                    ch = sys.stdin.read(1)
                finally:
                    termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
                return ch
                   # Uses Dynamixel SDK library

# Control table address
        ADDR_MX_TORQUE_ENABLE      = connection_variables["ADDR_MX_TORQUE_ENABLE"]               # Control table address is different in Dynamixel model
        ADDR_MX_GOAL_POSITION      = connection_variables["ADDR_MX_GOAL_POSITION"]
        ADDR_MX_PRESENT_POSITION   = connection_variables["ADDR_MX_PRESENT_POSITION"]

# Protocol version
        PROTOCOL_VERSION            = connection_variables["PROTOCOL_VERSION"]          # See which protocol version is used in the Dynamixel

# Default setting
        DXL_ID                      = connection_variables["DXL_ID"]               # Dynamixel ID : 1
        BAUDRATE                    = connection_variables["BAUDRATE"]             # Dynamixel default baudrate : 57600
        DEVICENAME                  = connection_variables["DEVICENAME"]    # Check which port is being used on your controller
                                                # ex) Windows: "COM1"   Linux: "/dev/ttyUSB0" Mac: "/dev/tty.usbserial-*"

        TORQUE_ENABLE               = connection_variables["TORQUE_ENABLE"]                 # Value for enabling the torque
        TORQUE_DISABLE              = connection_variables["TORQUE_DISABLE"]                 # Value for disabling the torque
        DXL_MINIMUM_POSITION_VALUE  = connection_variables["DXL_MINIMUM_POSITION_VALUE"]           # Dynamixel will rotate between this value
        DXL_MAXIMUM_POSITION_VALUE  = connection_variables["DXL_MAXIMUM_POSITION_VALUE"]            # and this value (note that the Dynamixel would not move when the position value is out of movable range. Check e-manual about the range of the Dynamixel you use.)
        DXL_MOVING_STATUS_THRESHOLD = connection_variables["DXL_MOVING_STATUS_THRESHOLD"]                # Dynamixel moving status threshold

        index = 0
        dxl_goal_position = [DXL_MINIMUM_POSITION_VALUE, DXL_MAXIMUM_POSITION_VALUE]         # Goal position


# Initialize PortHandler instance
# Set the port path
# Get methods and members of PortHandlerLinux or PortHandlerWindows
        portHandler = PortHandler(DEVICENAME)

# Initialize PacketHandler instance
# Set the protocol version
# Get methods and members of Protocol1PacketHandler or Protocol2PacketHandler
        packetHandler = PacketHandler(PROTOCOL_VERSION)

# Open port
        if portHandler.openPort():
            print("Succeeded to open the port")
        else:
            print("Failed to open the port")
            print("Press any key to terminate...")
            getch()
            quit()


# Set port baudrate
        if portHandler.setBaudRate(BAUDRATE):
            print("Succeeded to change the baudrate")
        else:
            print("Failed to change the baudrate")
            print("Press any key to terminate...")
            getch()
            quit()

# Enable Dynamixel Torque
        dxl_comm_result, dxl_error = packetHandler.write1ByteTxRx(portHandler, DXL_ID, ADDR_MX_TORQUE_ENABLE, TORQUE_ENABLE)
        if dxl_comm_result != COMM_SUCCESS:
            print("%s" % packetHandler.getTxRxResult(dxl_comm_result))
        elif dxl_error != 0:
            print("%s" % packetHandler.getRxPacketError(dxl_error))
        else:
            print("Dynamixel has been successfully connected")

        while 1:
            print("Press any key to continue! (or press ESC to quit!)")
            if getch() == chr(0x1b):
                break

    # Write goal position
            dxl_comm_result, dxl_error = packetHandler.write4ByteTxRx(portHandler, DXL_ID, ADDR_MX_GOAL_POSITION, dxl_goal_position[index])
            if dxl_comm_result != COMM_SUCCESS:
                print("%s" % packetHandler.getTxRxResult(dxl_comm_result))
            elif dxl_error != 0:
                print("%s" % packetHandler.getRxPacketError(dxl_error))

            while 1:
        # Read present position
                dxl_present_position, dxl_comm_result, dxl_error = packetHandler.read4ByteTxRx(portHandler, DXL_ID, ADDR_MX_PRESENT_POSITION)
                if dxl_comm_result != COMM_SUCCESS:
                    print("%s" % packetHandler.getTxRxResult(dxl_comm_result))
                elif dxl_error != 0:
                    print("%s" % packetHandler.getRxPacketError(dxl_error))

                print("[ID:%03d] GoalPos:%03d  PresPos:%03d" % (DXL_ID, dxl_goal_position[index], dxl_present_position))

                if not abs(dxl_goal_position[index] - dxl_present_position) > DXL_MOVING_STATUS_THRESHOLD:
                    break

    # Change goal position
            if index == 0:
                index = 1
            else:
                index = 0


# Disable Dynamixel Torque
        dxl_comm_result, dxl_error = packetHandler.write1ByteTxRx(portHandler, DXL_ID, ADDR_MX_TORQUE_ENABLE, TORQUE_DISABLE)
        if dxl_comm_result != COMM_SUCCESS:
            print("%s" % packetHandler.getTxRxResult(dxl_comm_result))
        elif dxl_error != 0:
            print("%s" % packetHandler.getRxPacketError(dxl_error))

# Close port
        portHandler.closePort()

        s.connect((connection_variables["host"], connection_variables["port"]))
        
        """TODO: Connect to the robot"""
        print('Connecting to the robot...')

    def disconn(self):

        #connection.close()



        #sock.close()
        s.disconnect((connection_variables["host"], connection_variables["port"]))
        """TODO: Disconnect from the robot"""
        print('Disconnecting from the robot...')

    def close_app(self):
        """Safely close the program"""
        self.quit()
        self.master.destroy()
#class Exit:
 

if __name__ == '__main__':
    root = Tk()
    RobotController(root).pack(side='top', fill='both', expand=True)
    root.mainloop()
