import matplotlib.pyplot as plt
from math import pi, sin, cos
from numpy import matrix, double
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from numpy import matrix, vectorize
from random import random
import sys
import math
import forward_left_leg
import forward_right_leg
def forward_right_leg(theta1_r,theta2_r,theta3_r,theta4_r,theta5_r,theta6_r):
    alf0, a0, d1 = 0, 0, 0
    alf1, a1, d2 = (-math.pi) / 2, 0, 0
    alf2, a2, d3 = math.pi / 2, 0, 0
    alf3, a3, d4 = -(math.pi) / 2, 318, 0
    alf4, a4, d5 = 0, 318, 0
    alf5, a5, d6 = math.pi / 2, 0, 0  # AngleSubstitution, if all zero the frames will be represented in the home position
    #t1=sliders2[0].get()
    #t2=sliders2[1].get()
    #t3=sliders2[2].get()
    #t4=sliders2[3].get()
    #t5=sliders2[4].get()
    #t6=sliders2[5].get()
    
    t1=theta1_r*math.pi/180
    t2=theta2_r*math.pi/180+math.pi/2
    t3=theta3_r*math.pi/180
    t4=theta4_r*math.pi/180
    t5=theta5_r*math.pi/180
    t6=theta6_r*math.pi/180
    
    #= 0, (math.pi) / 2, 0, math.pi/2, 0, 0

    T01 = matrix([
        [cos(t1), -sin(t1), 0, a0],
        [sin(t1) * cos(alf0), cos(t1) * cos(alf0), -sin(alf0), -sin(alf0) * d1],
        [sin(t1) * sin(alf0), cos(t1) * sin(alf0), cos(alf0), cos(alf0) * d1],
        [0, 0, 0, 1]
    ])

    T12 = matrix([
        [cos(t2), -sin(t2), 0, a1],
        [sin(t2) * cos(alf1), cos(t2) * cos(alf1), -sin(alf1), -sin(alf1) * d2],
        [sin(t2) * sin(alf1), cos(t2) * sin(alf1), cos(alf1), cos(alf1) * d2],
        [0, 0, 0, 1]
    ])
    T23 = matrix([
        [cos(t3), -sin(t3), 0, a2],
        [sin(t3) * cos(alf2), cos(t3) * cos(alf2), -sin(alf2), -sin(alf2) * d3],
        [sin(t3) * sin(alf2), cos(t3) * sin(alf2), cos(alf2), cos(alf2) * d3],
        [0, 0, 0, 1]
    ])
    T34 = matrix([
        [cos(t4), -sin(t4), 0, a3],
        [sin(t4) * cos(alf3), cos(t4) * cos(alf3), -sin(alf3), -sin(alf3) * d4],
        [sin(t4) * sin(alf3), cos(t4) * sin(alf3), cos(alf3), cos(alf3) * d4],
        [0, 0, 0, 1]
    ])
    T45 = matrix([
        [cos(t5), -sin(t5), 0, a4],
        [sin(t5) * cos(alf4), cos(t5) * cos(alf4), -sin(alf4), -sin(alf4) * d5],
        [sin(t5) * sin(alf4), cos(t5) * sin(alf4), cos(alf4), cos(alf4) * d5],
        [0, 0, 0, 1]
    ])
    T56 = matrix([
        [cos(t6), -sin(t6), 0, a5],
        [sin(t6) * cos(alf5), cos(t6) * cos(alf5), -sin(alf5), -sin(alf5) * d6],
        [sin(t6) * sin(alf5), cos(t6) * sin(alf5), cos(alf5), cos(alf5) * d6],
        [0, 0, 0, 1]
    ])

    # Foot Frame {F}
    L5 = 50  # in mm
    L6 = 100
    T6F = matrix([
        [cos(-math.pi / 2), 0, -sin(-math.pi / 2), L5],
        [0, 1, 0, 0],
        [sin(-math.pi / 2), 0, cos(-math.pi / 2), L6],
        [0, 0, 0, 1]
    ])
    # ------------------------------------------------------------------------------------
    T02 = T01 * T12
    T03 = T02 * T23
    T04 = T03 * T34
    T05 = T04 * T45
    T06 = T05 * T56


    convert_to_int = vectorize(lambda T06: int(T06))
    T06=convert_to_int(T06)
    print(T06)

    convert_to_int = vectorize(lambda T6F: int(T6F))
    T6F=convert_to_int(T6F)
    print(T6F)

    T0F = T06 * T6F

    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    ax.set_xlim([-9, 9])
    ax.set_ylim([-9, 9])
    ax.set_zlim([-10, 9])

    # Scaling the frame axis and the dimensions of the robot
    scale1 = 4
    scale2 = 3.5
    scale3 = 2
    scale4 = 1
    # Scaling the link lengths
    scaleD = 80
    #scaleF = 63601
    orange = [0.9100, 0.4100, 0.1700]
    FontScale = 11

    convert_to_int = vectorize(lambda T02: int(T02))
    T02=convert_to_int(T02)
    print(T02)

    convert_to_int = vectorize(lambda T03: int(T03))
    T03=convert_to_int(T03)
    print(T03)


    convert_to_int = vectorize(lambda T04: int(T04))
    T04=convert_to_int(T04)
    print(T04)

    convert_to_int = vectorize(lambda T05: int(T05))
    T05=convert_to_int(T05)
    print(T05)




    convert_to_int = vectorize(lambda T0F: int(T0F))
    T0F=convert_to_int(T0F)
   
    #scale_2=5.5

    ax.quiver(0, 0, 0, scale1, 0, 0, color='red') 
    ax.quiver(0, 0, 0, 0, scale1, 0, color='red')
    ax.quiver(0, 0, 0, 0, 0, scale1, color='red')
    ax.text(scale1, 0, 0, '{X_0}', fontsize=8, color='red')
    ax.text(0, scale1, 0, '{Y_0}', fontsize=8, color='red')
    ax.text(0, 0, scale1, '{Z_0}', fontsize=8, color='red')

    #scale_X_1_X=6.5
    #scale_Y_1_frame_1=7.5
    ax.quiver(0, 0, 0, T01[0, 0] * scale2, double(T01[1, 0]) * scale2, double(T01[2, 0]) * scale2, color='blue')
    ax.quiver(0, 0, 0, double(T01[0, 1]) * scale2, double(T01[1, 1]) * scale2, double(T01[2, 1]) * scale2, color='blue')
    ax.quiver(0, 0, 0, double(T01[0, 2]) * scale2, double(T01[1, 2]) * scale2, double(T01[2, 2]) * scale2, color='blue')
    ax.text(T01[0, 0] * scale2, double(T01[1, 0]) * scale2, double(T01[2, 0]) * scale2, '{X_1}', fontsize=8, color='blue')
    ax.text(double(T01[0, 1]) * scale2, double(T01[1, 1]) * scale2, double(T01[2, 1]) * scale2, '{Y_1}', fontsize=8, color='blue')
    ax.text(double(T01[0, 2]) * scale2, double(T01[1, 2]) * scale2, double(T01[2, 2]) * scale2, '{Z_1}', fontsize=8, color='blue')

    #print(T0F)
    #scale_X_2_Z=4.5
    #scale_X_2_X=2.5
    ax.quiver(0, 0, 0, double(T02[0, 0] * scale3), double(T02[1, 0] * scale3), double(T02[2, 0] * scale3), color='green')
    ax.quiver(0, 0, 0, double(T02[0, 1] * scale3), double(T02[1, 1] * scale3), double(T02[2, 1] * scale3), color='green')
    ax.quiver(0, 0, 0, double(T02[0, 2] * scale3), double(T02[1, 2] * scale3), double(T02[2, 2] * scale3), color='green')
    ax.text(double(T02[0, 0] * scale3), double(T02[1, 0] * scale3), double(T02[2, 0] * scale3), '{X_2}', fontsize=8, color='green')
    ax.text(double(T02[0, 1] * scale3), double(T02[1, 1] * scale3), double(T02[2, 1] * scale3), '{Y_2}', fontsize=8, color='green')
    ax.text(double(T02[0, 2] * scale3), double(T02[1, 2] * scale3), double(T02[2, 2] * scale3), '{Z_2}', fontsize=8, color='green')

    ax.quiver(0, 0, 0, double(T03[0, 0] * scale4), double(T03[1, 0] * scale4), double(T03[2, 0] * scale4), color='orange')
    ax.quiver(0, 0, 0, double(T03[0, 1] * scale4), double(T03[1, 1] * scale4), double(T03[2, 1] * scale4), color='orange')
    ax.quiver(0, 0, 0, double(T03[0, 2] * scale4), double(T03[1, 2] * scale4), double(T03[2, 2] * scale4), color='orange')
    ax.text(double(T03[0, 0] * scale4), double(T03[1, 0] * scale4), double(T03[2, 0] * scale4), '{X_3}', fontsize=8, color='orange')
    ax.text(double(T03[0, 1] * scale4), double(T03[1, 1] * scale4), double(T03[2, 1] * scale4), '{Y_3}', fontsize=8, color='orange')
    ax.text(double(T03[0, 2] * scale4), double(T03[1, 2] * scale4), double(T03[2, 2] * scale4), '{Z_3}', fontsize=8, color='orange')

    #print(double(T05[2, 1]) )
    #print(double(T05[2, 1]) )
    #scale_4_X_and_Y=0.5*10**17
    #scale_4_X=4.5
    #scale_4_Z=-0.75*10**17

    ax.quiver(double(T04[0, 3]) / scaleD, double(T04[1, 3]) / scaleD, double(T04[2, 3]) / scaleD,
              double(T04[0, 0]) * scale3, double(T04[1, 0]) * scale3, double(T04[2, 0]) * scale3, color='orange')
    ax.quiver(double(T04[0, 3]) / scaleD, double(T04[1, 3]) / scaleD, double(T04[2, 3]) / scaleD,
              double(T04[0, 1]) * scale3, double(T04[1, 1]) * scale3, double(T04[2, 1]) * scale3, color='orange')
    ax.quiver(double(T04[0, 3]) / scaleD, double(T04[1, 3]) / scaleD, double(T04[2, 3]) / scaleD,
              double(T04[0, 2]) * scale3, double(T04[1, 2]) * scale3, double(T04[2, 2]) * scale3, color='orange')
    ax.text((double(T04[0,3])/scaleD+double(T04[0,0])*scale3),(double(T04[1,3])/scaleD+double(T04[1,0])*scale3),(double(T04[2,3])/scaleD+double(T04[2,0])*scale3), '{X_4}', fontsize=8, color='orange')
    ax.text((double(T04[0,3])/scaleD+double(T04[0,1])*scale3),(double(T04[1,3])/scaleD+double(T04[1,1])*scale3),(double(T04[2,3])/scaleD+double(T04[2,1])*scale3), '{Y_4}', fontsize=8, color='orange')
    ax.text((double(T04[0,3])/scaleD+double(T04[0,2])*scale3),(double(T04[1,3])/scaleD+double(T04[1,2])*scale3),(double(T04[2,3])/scaleD+double(T04[2,2])*scale3), '{Z_4}', fontsize=8, color='orange')

    #print(T04)

    #scale5_text=20000

    #scale5_F_text=7.5

    #scale_5_X_text=1.5*10000
    #scale_5_Y=1.5*10**17
    #scale_5_Z=1.5*(-1)*10**17

    ax.quiver(double(T05[0, 3]) / scaleD, double(T05[1, 3]) / scaleD, double(T05[2, 3]) / scaleD,
              double(T05[0, 0]) * scale3, double(T05[1, 0]) * scale2, double(T05[2, 0]) * scale3, color='orange')
    ax.quiver(double(T05[0, 3]) / scaleD, double(T05[1, 3]) / scaleD, double(T05[2, 3]) / scaleD,
              double(T05[0, 1]) * scale3, double(T05[1, 1]) * scale2, double(T05[2, 1]) * scale3, color='orange')
    ax.quiver(double(T05[0, 3]) / scaleD, double(T05[1, 3]) / scaleD, double(T05[2, 3]) / scaleD,
              double(T05[0, 2]) * scale3, double(T05[1, 2]) * scale2, double(T05[2, 2]) * scale3, color='orange')
    ax.text((double(T05[0,3])/scaleD+double(T05[0,0])*scale2),(double(T05[1,3])/scaleD+double(T05[1,0])*scale3),(double(T05[2,3])/scaleD+double(T05[2,0])*scale3), '{X_5}', fontsize=8, color='orange')
    ax.text((double(T05[0,3])/scaleD+double(T05[0,1])*scale2),(double(T05[1,3])/scaleD+double(T05[1,1])*scale3),(double(T05[2,3])/scaleD+double(T05[2,1])*scale3), '{Y_5}', fontsize=8, color='orange')
    ax.text((double(T05[0,3])/scaleD+double(T05[0,2])*scale2),(double(T05[1,3])/scaleD+double(T05[1,2])*scale3),(double(T05[2,3])/scaleD+double(T05[2,2])*scale3), '{Z_5}', fontsize=8, color='orange')


    #scale6_text=20000

    #scale6_F_text=6*1.5
    #scale_6_X_and_Y=4
    #scale_6_X_text=10000
    #scale_6_Y_and_Z=1.5*10**17*(-1)
    ax.quiver(double(T06[0, 3]) / scaleD, double(T06[1, 3]) / scaleD, double(T06[2, 3]) / scaleD,
              double(T06[0, 0]) * scale4, double(T06[1, 0]) * scale3, double(T06[2, 0]) * scale4, color='green')
    ax.quiver(double(T06[0, 3]) / scaleD, double(T06[1, 3]) / scaleD, double(T06[2, 3]) / scaleD,
              double(T06[0, 1]) * scale4, double(T06[1, 1]) * scale3, double(T06[2, 1]) * scale4, color='green')
    ax.quiver(double(T06[0, 3]) / scaleD, double(T06[1, 3]) / scaleD, double(T06[2, 3]) / scaleD,
              double(T06[0, 2]) * scale4, double(T06[1, 2]) * scale3, double(T06[2, 2]) * scale4, color='green')
    ax.text((double(T06[0,3])/scaleD+double(T06[0,0])*scale3),(double(T06[1,3])/scaleD+double(T06[1,0])*scale4),(double(T06[2,3])/scaleD+double(T06[2,0])*scale4), '{X_6}', fontsize=8, color='green') 
    ax.text((double(T06[0,3])/scaleD+double(T06[0,1])*scale3),(double(T06[1,3])/scaleD+double(T06[1,1])*scale4),(double(T06[2,3])/scaleD+double(T06[2,1])*scale4), '{Y_6}', fontsize=8, color='green') 
    ax.text((double(T06[0,3])/scaleD+double(T06[0,2])*scale3),(double(T06[1,3])/scaleD+double(T06[1,2])*scale4),(double(T06[2,3])/scaleD+double(T06[2,2])*scale4), '{Z_6}', fontsize=8, color='green')

    scaleF_text=20000

    #scale3_F_text=3.5
    #scale_F_X_text=10000
    #scale_F_Y=5
    #scale_F_Y_Z=10**17*(-1)*1.5

    ax.quiver(double(T0F[0, 3]) / scaleD, double(T0F[1, 3]) / scaleD, double(T0F[2, 3]) / scaleD,
              double(T0F[0, 0]) * scale3, double(T0F[1, 0]) * scale3, double(T0F[2, 0]) * scale3 , color='red')

    ax.quiver(double(T0F[0, 3]) / scaleD, double(T0F[1, 3]) / scaleD, double(T0F[2, 3]) / scaleD,
              double(T0F[0, 1]) * scale3, double(T0F[1, 1]) * scale3, double(T0F[2, 1]) * scale3, color='red')
    ax.quiver(double(T0F[0, 3]) / scaleD, double(T0F[1, 3]) / scaleD, double(T0F[2, 3]) / scaleD,
              double(T0F[0, 2]) * scale3, double(T0F[1, 2]) * scale3, double(T0F[2, 2]) * scale3 , color='red')
    ax.text((double(T0F[0,3])/scaleD+double(T0F[0,0])*scale3),(double(T0F[1,3])/scaleD+double(T0F[1,0])*scale3),(double(T0F[2,3])/scaleD+double(T0F[2,0])*scale3), '{X_F}', fontsize=8,color='red') 
    ax.text((double(T0F[0,3])/scaleD+double(T0F[0,1])*scale3),(double(T0F[1,3])/scaleD+double(T0F[1,1])*scale3),(double(T0F[2,3])/scaleD+double(T0F[2,1])*scale3), '{Y_F}', fontsize=8, color='red')
    ax.text((double(T0F[0,3])/scaleD+double(T0F[0,2])*scale3),(double(T0F[1,3])/scaleD+double(T0F[1,2])*scale3),(double(T0F[2,3])/scaleD+double(T0F[2,2])*scale3), '{Z_F}', fontsize=8, color='red')

    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z') 
    plt.show()
    return
