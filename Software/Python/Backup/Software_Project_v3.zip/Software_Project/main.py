import matplotlib.pyplot as plt
from math import pi, sin, cos
from numpy import matrix, double
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from numpy import matrix, vectorize
from random import random
import sys
import math
import forward_left_leg
import forward_right_leg
import math
##from gimpfu import *
      
try:
    # for Python2
    from Tkinter import *   ## notice catalized T in Tkinter 
except ImportError:
    # for Python3
    from tkinter import *
from tkinter import ttk
import os
import socket
#The following values for t6,c2, t4, t5, e3 do not make sense as long as they will be updated in the fucntions, they are just declared
t6=0
c2=math.pi/2
t4=math.pi/2
t5=0
e3=0
##def extreme_unsharp_desaturation(image, drawable):
##    register(
##    "python-fu-extreme-unsharp-desaturation",
##    "Unsharp mask and desaurate image",
##    "Run an unsharp mask with amount set to 5, then desaurate image",
##    "Jackson Bates", "Jackson Bates", "2015",
##    "Extreme unsharp and desaturate",
##    "RGB", 
##    [
##        (PF_IMAGE, "image", "takes current image", None),
##        (PF_DRAWABLE, "drawable", "Input layer", None)
##    ],
##    [],
##    extreme_unsharp_desaturation, menu="/Filters/Enhance")


class calculate:
    pass

global alp
alp=0
global bet
bet=0
global gam
gam=0
#button 4 -- image button (round rect)

#Function for updating entry text
class Text:
    def update(event,slr,edit):
        edit.delete(0,'end')
        edit.insert(0,str(slr.get()))

#Function for updating slider value
class Slider:
    def updateSlider(event,edit,slider):
        if len(edit.get())>0:
            #only numbers allowed
            for c in edit.get():
                if c in "0123456789.-":
                    print()
                else:
                    #if detected a letter remove all and set to 0
                    slider.set(0)
                    edit.delete(0, 'end')
                    edit.insert(0, "0")
                    return
    
            slider.set(float(edit.get()))
        else:
            slider.set(0)
    def updateSlider2(event,edit,slider2):
        if len(edit.get())>0:
            #only numbers allowed
            for c in edit.get():
                if c in "0123456789.-":
                    print()
                else:
                    #if detected a letter remove all and set to 0
                    slider2.set(0)
                    edit.delete(0, 'end')
                    edit.insert(0, "0")
                    return
    
            slider2.set(float(edit.get()))
        else:
            slider2.set(0)

class Connection:
    s = socket.socket()
    def disconn():
        Connection.s.disconnect((host, port))
    
    def conn():
        Connection.s.connect((host, port))
#Function for sending text via LAN

class ForwardKinematics:
    def show_left():
##        str=""
##        for i in range(0,len(entries)):
##            str=str+entries[i].get()+"_"
        plt.close()
        ForwardLeg.left(double(SlidEntry.sliders[0].get()),double(SlidEntry.sliders[1].get()),double(SlidEntry.sliders[2].get()),double(SlidEntry.sliders[3].get()),double(SlidEntry.sliders[4].get()),double(SlidEntry.sliders[5].get()))
    
    
    def show_right():
##        str=""
##        for i in range(0,len(entries2)):
##            str=str+entries2[i].get()+"_"
        plt.close()
        ForwardLeg.right(double(SlidEntry.sliders2[0].get()),double(SlidEntry.sliders2[1].get()),double(SlidEntry.sliders2[2].get()),double(SlidEntry.sliders2[3].get()),double(SlidEntry.sliders2[4].get()),double(SlidEntry.sliders2[5].get()))
    
    
    def send1():
        str=""
        for i in range(0,len(entries)):
            str=str+entries[i].get()+"_"
            print(i)
    #s.send(str)
    #forward_left_leg(double(sliders[0].get()),double(sliders[1].get()),double(sliders[2].get()),double(sliders[3].get()),double(sliders[4].get()),double(sliders[5].get()))
    #plt.close()
    
    def send2():
        str=""
        for i in range(0,len(entries)):
            str=str+entries[i].get()+"_"
    #s.send(str)
    #Exit
    #forward_right_leg(double(sliders2[0].get()),double(sliders2[1].get()),double(sliders2[2].get()),double(sliders2[3].get()),double(sliders2[4].get()),double(sliders2[5].get()))

class GUI:
    def quit(event):
        master.quit()
        Connection.s.close()
#Number of motors
N=10




#create main window
class Window:
    master=Tk()



MYGREEN = "#d2ffd2"
MYRED = "#dd0202"

class Style:
    style = ttk.Style()
    style.theme_create( "mfx", parent="alt", settings={
        "TNotebook": {"configure": {"tabmargins": [2, 5, 2, 0] } },
        "TNotebook.Tab": {
            "configure": {"padding": [5, 1], "background": MYGREEN },
            "map":       {"background": [("selected", MYRED)],
                          "expand": [("selected", [1, 1, 1, 0])] } } } )
    
    style.theme_use("mfx")


#create tabs
class Tab:
    notebook=ttk.Notebook(Window.master)
    notebook.pack()
    #tab1
    subframe1=Frame(Window.master)
    subframe1.pack()
    notebook.add(subframe1,text="Connect",state="normal")
    #tab2
    subframe2=Frame(Window.master)
    subframe2.pack()
    notebook.add(subframe2,text="Left Leg",state="normal")
    #tab2
    subframe3=Frame(Window.master)
    subframe3.pack()
    notebook.add(subframe3,text="Right Leg",state="normal")
    #tab3
    subframe4=Frame(Window.master)
    subframe4.pack()
    notebook.add(subframe4,text="Invrerse Kinematics")
    
    
    ##b = Button(subframe3, text="Close", width=1, command=subframe3.destroy, fg="green")
    e = Entry(subframe4)
    e.pack()
    e.config(width=7)
    e.insert(0,"x (Leg 1)")
    #e.grid(row=256,column=256) 
    
    e2 = Entry(subframe4, text="y (Leg 1)")
    e2.pack()
    e2.config(width=7)
    e2.insert(0,"y (Leg 1)")
    
    e3 = Entry(subframe4)
    e3.pack()
    e3.config(width=7)
    e3.insert(0,"z (Leg 1)")
    
    e4 = Entry(subframe4)
    e4.pack()
    e4.config(width=7)
    e4.insert(0,"x (Leg 2)")
    
    e5 = Entry(subframe4)
    e5.pack()
    e5.config(width=7)
    e5.insert(0,"y (Leg 2)")
    
    e6 = Entry(subframe4)
    e6.pack()
    e6.config(width=7)
    e6.insert(0,"z (Leg 2)")

class InverseKinematics:
    def inverse_kin_leg1():
        px=float(e.get())
        py=float(e2.get())
        pz=float(e3.get())
        L3=1
        L4=1
        c4=(px**2+py**2+pz**2-L3**2-L4**2)**2
        t4=math.atan2(math.sqrt(math.fabs(1-c4**2)),c4)
        k1=(L3*math.cos(t4)+L4)
        k2=L3*math.sin(t4)
        k3=math.sqrt(px**2+py**2+pz**2)
        t5=math.atan2((k2*k3-pz)/(k1+k2**2/k1),(k3+k2)/k1*(k2*k3/k1-pz)/(k1+k2**2/k1))
        print("py=")
        print(py)
        print("px=")
        print(px)
        t6=math.atan2(py,-px)
        s2=-math.sin(alp)*math.sin(t6)*math.sin(t4 + t5)*math.cos(bet) + math.sin(bet)*math.sin(t4 + t5)*math.cos(t6) + math.cos(alp)*math.cos(bet)*math.cos(t4 + t5)
        c2=math.sqrt(1-s2**2)
        t2=math.atan2(s2,c2)
        t2_radian=t2*180/math.pi
        t1=math.atan2((-(math.sin(alp)*math.cos(gam) - math.sin(bet)*math.sin(gam)*math.cos(alp))*math.cos(t4 + t5) + (math.sin(alp)*math.sin(bet)*math.sin(gam) + math.cos(alp)
  *math.cos(gam))*math.sin(t6)*math.sin(t4 + t5) - math.sin(gam)*math.sin(t4 + t5)*math.cos(bet)*math.cos(t6))/c2,((math.sin(alp)*math.sin(gam) + math.sin(bet)*math.cos(alp)*math.cos(gam))*math.cos(t4 + t5) + (math.sin(alp)*math.sin(bet)*math.cos(gam) - math.sin(gam)*
  math.cos(alp))*math.sin(t6)*math.sin(t4 + t5) - math.sin(t4 + t5)*math.cos(bet)*math.cos(gam)*math.cos(t6))/c2)
        print("t6=")
        print(t6)
        t3= math.atan2((math.sin(alp)*math.cos(bet)*math.cos(t6) - math.sin(bet)*math.sin(t6))/c2,-( -math.sin(alp)*math.sin(t6)*math.cos(bet)*math.cos(t4 + t5) - math.sin(bet)*math.cos(t6)*math.cos(t4 + t5) + math.sin(t4 + t5)*math.cos(alp)*math.cos(bet
  ))/c2)
        e4.insert(0,t2_radian)
    
    #def inverse_kin_leg1():
    #px=float(e.get())
    #py=float(e2.get())
    #pz=float(e3.get())
    #L3=1
    #L4=1
    #c4=(px**2+py**2+pz**2-L3**2-L4**2)**2
    #t4=math.atan2(math.sqrt(1-c4**2),1.5)
    #e5.insert(0,t4)
    def inverse_kin_leg2():
        px=float(e4.get())
        py=float(e5.get())
        pz=float(e6.get())
        L3=318.5
        L4=318.5
        c4=(px**2+py**2+pz**2-L3**2-L4**2)**2
        t4=math.atan2(math.sqrt(1-c4**2),c4)
        t5=math.atan2((k2*k3-pz)/(k1+k2**2/k1),(k3+k2)/k1*(k2*k3/k1-pz)/(k1+k2**2/k1))
        t6=math.atan2(py,-px)
        s2=-math.sin(alp)*math.sin(t6)*math.sin(t4 + t5)*math.cos(bet) + math.sin(bet)*math.sin(t4 + t5)*math.cos(t6) + math.cos(alp)*math.cos(bet)*math.cos(t4 + t5)
        c2=math.sqrt(1-s2**2)
        t2=math.atan2(s2,c2)
        t1=math.atan2((-(math.sin(alp)*math.cos(gam) - math.sin(bet)*math.sin(gam)*math.cos(alp))*math.cos(t4 + t5) + (math.sin(alp)*math.sin(bet)*math.sin(gam) + math.cos(alp)
  *math.cos(gam))*math.sin(t6)*math.sin(t4 + t5) - math.sin(gam)*math.sin(t4 + t5)*math.cos(bet)*math.cos(t6))/c2,((math.sin(alp)*math.sin(gam) + math.sin(bet)*math.cos(alp)*math.cos(gam))*math.cos(t4 + t5) + (math.sin(alp)*math.sin(bet)*math.cos(gam) - math.sin(gam)*
  math.cos(alp))*math.sin(t6)*math.sin(t4 + t5) - math.sin(t4 + t5)*math.cos(bet)*math.cos(gam)*math.cos(t6))/c2)
    t3= math.atan2((math.sin(alp)*math.cos(bet)*math.cos(t6) - math.sin(bet)*math.sin(t6))/c2,-( -math.sin(alp)*math.sin(t6)*math.cos(bet)*math.cos(t4 + t5) - math.sin(bet)*math.cos(t6)*math.cos(t4 + t5) + math.sin(t4 + t5)*math.cos(alp)*math.cos(bet
  ))/c2)
    
    Tab.e3.insert(0,t4)
    b = [6]
    b[0]= Button(Tab.subframe4, text="Leg 1 IK", command=inverse_kin_leg1)
    b[0].config(width=10)
    b[0].pack()
    b1 = Button(Tab.subframe4, text="Leg 2 IK", command=inverse_kin_leg2)
    b1.config(width=10)
    b1.pack()






#Display Image (plan of the motors)
#img=Image.open("/home/nu-humanoid/Downloads/StartSoftwareProject_v2_sliders_are_increased_v6/plan.jpg")
#photo=ImageTk.PhotoImage(img)
#label = Label(subframe4,image=photo)
#label.image = photo # keep a reference!
#label.pack()

#Fill the window with sliders and entries
class ForwardLeg:
    from forward_left_leg import forward_left_leg as left
    from forward_right_leg import forward_right_leg as right

class SlidEntry:
    entries=[]
    sliders=[]
    entries2=[]
    sliders2=[]
    for i in range(0,6):
        if i==0:
            lb=Label(Tab.subframe2, text= "hip yaw joint")
        elif i==1:
            lb=Label(Tab.subframe2, text ="hip roll joint")
        #    lb=Label()
        elif i==2:
            lb=Label(Tab.subframe2, text ="hip pitch joint")
        elif i==3:
            lb=Label(Tab.subframe2, text ="knee joint")
        elif i==4:
            lb=Label(Tab.subframe2, text ="ankle yaw joint")
        else:
            lb=Label(Tab.subframe2, text ="ankle roll joint")
        
        lb.grid(row=i+1,column=0,sticky="w")
        entries.append(Entry(Tab.subframe2))
        entries[i].config(width=5)
        #def calculate(i):
        #   while i>=5:forward_left_leg(double(sliders[0].get()),double(sliders[1].get()),double(sliders[2].get()),double(sliders[3].get()),double(sliders[4].get()),double(sliders[5].get()))
        #  return 
        sliders.append(Scale(Tab.subframe2,from_=0,to=90,tickinterval=20,resolution=0.5,orient=HORIZONTAL,width=35))
        #,command=calculate
        sliders[i].config(length=200)
        sliders[i].bind('<ButtonRelease-1>',lambda x=i,arg1=sliders[i],arg2=entries[i]:Text.update(x,arg1,arg2))
        sliders[i].grid(row=i+1,column=1,sticky="w")
        entries[i].bind('<KeyRelease>',lambda y=i,arg1=sliders[i],arg2=entries[i]:Slider.updateSlider(y,arg2,arg1))
        entries[i].grid(row=i+1,column=2,sticky="w")
        sliders[i].set(0)
        entries[i].insert(0,"0")
        #calculate(i)   
        #forward_left_leg(double(sliders[0].get()),double(sliders[1].get()),double(sliders[2].get()),double(sliders[3].get()),double(sliders[4].get()),double(sliders[5].get()))
        #if (i==5 and (s)): plt.close()
        #if i==5:forward_left_leg(double(sliders[0].get()),double(sliders[1].get()),double(sliders[2].get()),double(sliders[3].get()),double(sliders[4].get()),double(sliders[5].get()))
        #if(i>=5):send1()    
        print(sliders[0].get())
        
    print("for loop i=")
    print(i)        
    for i in range(0,6):
        if i==0:
            lb2=Label(Tab.subframe3, text= "hip yaw joint")
        elif i==1:
            lb2=Label(Tab.subframe3, text ="hip roll joint")
            #    lb=Label()
        elif i==2:
            lb2=Label(Tab.subframe3, text ="hip pitch joint")
        elif i==3:
            lb2=Label(Tab.subframe3, text ="knee joint")
        elif i==4:
            lb2=Label(Tab.subframe3, text ="ankle yaw joint")
        else:
            lb2=Label(Tab.subframe3, text ="ankle roll joint")
        
        lb2.grid(row=i+1,column=0,sticky="w")
        entries2.append(Entry(Tab.subframe3))
        entries2[i].config(width=5)
        sliders2.append(Scale(Tab.subframe3,from_=0,to=90,tickinterval=20,resolution=0.5,orient=HORIZONTAL,width=35))
        sliders2[i].config(length=200)
        sliders2[i].bind('<ButtonRelease-1>',lambda x=i,arg1=sliders2[i],arg2=entries2[i]:Text.update(x,arg1,arg2))
        sliders2[i].grid(row=i+1,column=1,sticky="w")
        entries2[i].bind('<KeyRelease>',lambda y=i,arg1=sliders2[i],arg2=entries2[i]:Slider.updateSlider2(y,arg2,arg1))
        entries2[i].grid(row=i+1,column=2,sticky="w")
        sliders2[i].set(0)
        entries2[i].insert(0,"0")
##        def callback2(i):
##            plt.close()
##        sliders2[i].bind("<ButtonRelease-1>",callback2(1))
##        if i>=5:
##            sliders2[i].bind("<ButtonRelease-1>",ForwardLeg.right(double(sliders2[0].get()),double(sliders2[1].get()),double(sliders2[2].get()),double(sliders2[3].get()),double(sliders2[4].get()),double(sliders2[5].get()))
##       )

print('ok')
class Connection2:
    print('ok')
    conn = Button(Tab.subframe1, text = 'Connect',command=Connection.conn)
    #button_4.grid(column = 3 , row = 0)
    button_Image1 = PhotoImage(file = '/home/zhenis/Downloads/StartSoftwareProject_v2_sliders_are_increased_v6/green_con_button.gif')
    print('ok')
    conn.configure(image = button_Image1,bg = 'white')
    conn.pack(side=TOP)
    conn.grid(row=1,column=0)
    conn.place(relx=0.2, rely=0.48)
    
    #Disconnect button
    disconn=Button(Tab.subframe1, text="Disconnect", command=Connection.disconn)
    button_Image2 = PhotoImage(file = '/home/zhenis/Downloads/StartSoftwareProject_v2_sliders_are_increased_v6/discon_but.png')
    disconn.configure(image = button_Image2,bg = 'white')
    disconn.pack(side=TOP)
    disconn.grid(row=50,column=50)
    disconn.place(relx=0.6, rely=0.48)


def save(self):
    self.conn.config(relief=SUNKEN, vg="green")
    # if you also want to disable it do:
    # self.button0.config(state=tk.DISABLED)
    #...

def stop(self):
    self.conn.config(relief=RAISED, bg="red")
    # if it was disabled above, then here do:
    # self.button0.config(state=tk.ACTIVE)
    #...
#conn = Button(subframe1, text = 'Connect',command=conn)

class ForwardKinematics2:
    show_left=Button(Tab.subframe2, text="show left leg frames", command=ForwardKinematics.show_left)
    show_left.grid(row=N+2,column=1)
    
    show_right=Button(Tab.subframe3, text="show right leg frames", command=ForwardKinematics.show_right)
    show_right.grid(row=N+2,column=1)
    
    send=Button(Tab.subframe2, text="send", command=ForwardKinematics.send1)
    send.grid(row=N+2,column=2)
    #Connect button
    #conn=Button(subframe2, text="Connect", command=conn)
    #conn.grid(row=0,column=0)
    send2=Button(Tab.subframe3, text="send", command=ForwardKinematics.send2)
    send2.grid(row=N+2,column=2)

#Exit button
class Exit:
    q=Button(Tab.subframe2, text="quit")
    q.bind('<Button-1>',quit)
    q.grid(row=N+3,column=1)
    #Exit button
    q=Button(Tab.subframe3, text="quit")
    q.bind('<Button-1>',quit)
    q.grid(row=N+3,column=1)


#_leg(double(sliders[0].get()),double(sliders[1].get()),double(sliders[2].get()),double(sliders[3].get()),double(sliders[4].get()),double(sliders[5].get()))

#identify network parameters

#host='169.254.16.136'
#port=12345

#s.connect((host,port))
#sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

#server_address = ('10.1.198.173', 8080)

#print(sys.stderr, 'starting up on %s port %s' % server_address)

#sock.bind(server_address)

#sock.listen(1)


#while True:

 #   connection, client_address = sock.accept()

  #  print(sys.stderr, 'connection from', client_address)

   # data = b'Hello from Raspberry PI'

    #connection.sendall(data)




#connection.close()

#sock.close()



#Connect button
#conn=Button(subframe1, text="Connect", command=conn)
#conn.pack(side=TOP)
#conn.grid(row=1,column=0)
#conn.place(relx=0.2, rely=0.48)

mainloop()
